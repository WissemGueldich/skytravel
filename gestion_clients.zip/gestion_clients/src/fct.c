#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "fct.h"
#include <gtk/gtk.h>

enum
{  NOM,
   PRENOM,
   ID,
   PASSWD,
   DATEADH,
   NUMTEL,
   COLUMNS
};

int controle_saisie_num(char x[20])
{
int t=0;
int i,a;
a=strlen(x);
for(i=0;i<=a;i++)
  {
    if (isdigit(x[i])!=0)
    {
      t=t+1;
    }
  }
  if(t==a)
      {return 1;}
  else {return 0;}

} 

int controle_saisie_id(char x[20])
{  int t=0;
   int i,a;
   a=strlen(x);
   for(i=0;i<=a;i++)
  {
    if (isalnum(x[i])!=0)
    {
      t=t+1;
    }
  }
  if(t==a)
      {return 1;}
  else {return 0;}



}

int controle_saisie_char(char x[])
{  int t=0;
   int a,i;
   a=strlen(x);
   for(i=0;i<=a;i++)
  {
    if (isalpha(x[i])!=0)
    {
      t=t+1;
    }
  }
  if(t==a)
      {return 1;}
  else {return 0;}
}



client chercher(char x[])
{
  client c;
  FILE  *f;
  f=fopen("clients.txt","r");

  if (f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s %s \n",c.nom,
      c.prenom,c.id,c.passwd,c.date_adh,c.num_tel)!=EOF)
      
          {
            if (strcmp(x,c.id)==0)
              {
                return c;
              }
          }
          
  }
  fclose(f);
  strcpy(c.id,"-1");
  return c;
}



void ajouter(client c)
{ FILE *f;
  
  f=fopen("/home/mariem/Bureau/gestion_clients/src/clients.txt","a+");
  if(f!=NULL)
  { 
    
    {fprintf(f,"%s %s %s %s %s %s \n",c.nom,c.prenom,c.id,c.passwd,c.date_adh,c.num_tel);
    }
    fclose(f);
  }
   

}



void afficher_client(GtkWidget *liste)
{ GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  
  GtkListStore *store;
  
  char nom[20];
  char prenom[20];
  char id[20];
  char passwd[20];
  char date_adh[20] ;
  char numtel[20] ;
  store=NULL;
  
  FILE *f;

  
  store=GTK_LIST_STORE(gtk_tree_view_get_model
      (GTK_TREE_VIEW(liste)));

  if (store==NULL)
  { 
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer =gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer =gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer =gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Password",renderer, "text",PASSWD, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer =gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date d'adhésion",renderer, "text",DATEADH, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer =gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Numéro de téléphone",renderer, "text",NUMTEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("/home/mariem/Bureau/gestion_clients/src/clients.txt", "r");

if (f==NULL)   
{
   return ;
}
else
{   
       while (fscanf(f, "%s %s %s %s %s %s \n",nom,prenom,id,passwd,date_adh,numtel)!=EOF)
       {gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,ID,id,PASSWD,passwd,DATEADH,date_adh ,NUMTEL,numtel,-1);
       }
        fclose(f);
        
}gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
        g_object_unref (store);
}




void modifier (client c)
{  client c1;
   FILE *f;
   FILE *f1;
   f=fopen("/home/mariem/Bureau/gestion_clients/src/clients.txt","a+");
   f1=fopen("/home/mariem/Bureau/gestion_clients/src/clients1.txt","a+");
   
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s %s\n",c1.nom,c1.prenom,c1.id,
      c1.passwd,c1.date_adh,c1.num_tel)!=EOF)
    {
      if(strcmp(c1.id,c.id)==0)
      {
        fprintf(f1,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.id,c.passwd,c.date_adh,c.num_tel);
      }
      else 
        fprintf(f1,"%s %s %s %s %s %s\n",c1.nom,c1.prenom,c1.id,c1.passwd,c1.date_adh,c1.num_tel);
    }
  }
  fclose(f);
  fclose(f1);
  remove("clients.txt");
  rename("clients1.txt","clients.txt");
}



void supprimer(client c)
{  client c1;
   FILE *f;
   FILE *f1;
   f=fopen("/home/mariem/Bureau/gestion_clients/src/clients.txt","a+");
   f1=fopen("/home/mariem/Bureau/gestion_clients/src/clients1.txt","a+");
   
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s %s\n",c1.nom,c1.prenom,c1.id,c1.passwd,c1.date_adh,c1.num_tel)!=EOF)
    {
      if(strcmp(c1.id,c.id)!=0)

     {fprintf(f1,"%s %s %s %s %s %s\n",c1.nom,c1.prenom,c1.id,c1.passwd,c1.date_adh,c1.num_tel);
     }
    }
  fclose(f);
  fclose(f1);
  remove("clients.txt");
  rename("clients1.txt","clients.txt");
  }
}

