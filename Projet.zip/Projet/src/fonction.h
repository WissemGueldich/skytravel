#include<gtk/gtk.h>
typedef struct
{ char nom[30];
  char prenom[30];
  char Datereclamation[30];
  char reclamation[300];
} Reclamation;

void ajouter_reclamation(Reclamation r);
void ajouter1_reclamation(Reclamation r);
void afficher_reclamation (GtkWidget *treeview1);
void afficher1_reclamation (GtkWidget *treeview2);
void afficher_reclamationrecherchee(GtkWidget *treeview1);
char* strspace(char c[]);
char* strnspace(char c[]);
