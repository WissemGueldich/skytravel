
#include<gtk/gtk.h>
typedef struct 
{
char matricule[100];
char couleur[100];
char modele[100];
char prix[100];
}voiture;

typedef struct
{
int jour ;
int mois;
int annee;
}date;

typedef struct
{
voiture v;
date de;
date ju;
}reservation;

void ajoutervoiture(voiture v);
void affichervoiture(GtkWidget *liste);
void supprimervoiture(char matricule[20]);
void modifiervoiture(voiture v);
void cherchervoiture(char matricule[20],int *a);
void reserver(reservation r , int ve);
int verifier(char couleur[20],char modele[20]);
void supprimer(voiture v);
void afficher(GtkWidget *liste);
