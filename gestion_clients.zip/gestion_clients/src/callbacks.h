#include <gtk/gtk.h>


void
on_modifier_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_update_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annuler2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_confirm_clicked                     (GtkWidget     *objet,
                                        gpointer         user_data);


