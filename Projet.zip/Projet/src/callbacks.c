
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_annuler1_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interface1, *reclamationAgent;
interface1=lookup_widget(objet_graphique,"interface1");
interface1=create_interface1();
reclamationAgent=lookup_widget(objet_graphique,"reclamationAgent");
gtk_widget_destroy(reclamationAgent);
gtk_widget_show(interface1);

}
void
on_button8_clicked                     (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interface1, *reclamationAdmin;
reclamationAdmin=lookup_widget(objet_graphique,"reclamationAdmin");
reclamationAdmin=create_reclamationAdmin();
interface1=lookup_widget(objet_graphique,"interface1");
gtk_widget_destroy(interface1);
gtk_widget_show(reclamationAdmin);



}
void
on_button15_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)   
{
GtkWidget *interfaceAgent, *Agent;
Agent=lookup_widget(objet_graphique,"Agent");
Agent=create_Agent();
interfaceAgent=lookup_widget(objet_graphique,"interfaceAgent");
gtk_widget_destroy(interfaceAgent);
gtk_widget_show(Agent);


}
void
on_button14_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)   
{
GtkWidget *interfaceAdmin, *Admin;
Admin=lookup_widget(objet_graphique,"Admin");
Admin=create_Admin();
interfaceAdmin=lookup_widget(objet_graphique,"interfaceAdmin");
gtk_widget_destroy(interfaceAdmin);
gtk_widget_show(Admin);
}


void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)   
{

}

void
on_button12_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)   
{
GtkWidget *interface1, *reclamationAgent;
reclamationAgent=lookup_widget(objet_graphique,"reclamationAgent");
reclamationAgent=create_reclamationAgent();
interface1=lookup_widget(objet_graphique,"interface1");
gtk_widget_destroy(interface1);
gtk_widget_show(reclamationAgent);

}


void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)   
{
GtkWidget *interface1; 
GtkWidget *reclamationAdmin;
reclamationAdmin=lookup_widget(objet_graphique,"reclamationAdmin");
reclamationAdmin=create_reclamationAdmin();
interface1=lookup_widget(objet_graphique,"interface1");
gtk_widget_destroy(interface1);
gtk_widget_show( reclamationAdmin);
}
void
on_button16_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Admin, *interfaceAdmin, *treeview1 ;
interfaceAdmin=lookup_widget(objet_graphique,"interfaceAdmin");
interfaceAdmin=create_interfaceAdmin();
Admin=lookup_widget(objet_graphique,"Admin");
gtk_widget_destroy(Admin); 
gtk_widget_show(interfaceAdmin);
treeview1=lookup_widget(interfaceAdmin, "treeview1");
afficher_reclamation(treeview1);
}


void
on_button17_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Agent, *interfaceAgent, *treeview2;
interfaceAgent=lookup_widget(objet_graphique,"interfaceAgent");
interfaceAgent=create_interfaceAgent();
Agent=lookup_widget(objet_graphique,"Agent");
gtk_widget_destroy(Agent);

gtk_widget_show(interfaceAgent);
treeview2=lookup_widget(interfaceAgent, "treeview2");
afficher1_reclamation(treeview2);
}


void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

FILE *F;
Reclamation r;
GtkWidget *reclamationAdmin;

GtkWidget *input5,*input6,*input7,*input8,*output1;
reclamationAdmin=lookup_widget(objet_graphique,"reclamationAdmin");
input5=lookup_widget(objet_graphique,"entry9");
input6=lookup_widget(objet_graphique,"entry10");
input7=lookup_widget(objet_graphique,"entry12");
input8=lookup_widget(objet_graphique,"entry6");

strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(r.Datereclamation,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(r.reclamation,gtk_entry_get_text(GTK_ENTRY(input8)));

F=fopen("/home/takwa/Desktop/Projet/src/fichier.txt","a+");

ajouter_reclamation(r);
fclose(F);
output1=lookup_widget(objet_graphique,"label42");
gtk_label_set_text(GTK_LABEL(output1),"votre reclamation a été bien envoyer");

}


void
on_envoyer1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *F;
Reclamation r;
GtkWidget *reclamationAgent;

GtkWidget *input1,*input2,*input3,*input4,*output;
reclamationAgent=lookup_widget(objet_graphique,"reclamationAgent");
input1=lookup_widget(objet_graphique,"entry7");
input2=lookup_widget(objet_graphique,"entry8");
input3=lookup_widget(objet_graphique,"entry11");
input4=lookup_widget(objet_graphique,"reclamation");

strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.Datereclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.reclamation,gtk_entry_get_text(GTK_ENTRY(input4)));
F=fopen("/home/takwa/Desktop/Projet/src/fichier1.txt","a+");

ajouter1_reclamation(r);
fclose(F);
output=lookup_widget(objet_graphique,"label37");
gtk_label_set_text(GTK_LABEL(output),"votre reclamation a été bien envoyer");
}



void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;

GtkWidget *interfaceAdmin;
GtkWidget *treeview1;
FILE *f1;
FILE *tmp1;
Reclamation r;
char ch[20];
int i=0;
input1=lookup_widget(objet_graphique,"entry13");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input1)));

f1=fopen("fichier.txt","r");

tmp1=fopen("tmp.txt","w");

while(fscanf(f1,"%s %s %s %s\n",r.nom,r.prenom,r.Datereclamation,r.reclamation)!=EOF)
{

strcat(r.nom," ");
strcat(r.nom,r.prenom);
if(strcmp(ch,r.nom)==0)
{i++;
fprintf(tmp1,"%s %s %s\n",r.nom,r.Datereclamation,r.reclamation);
break;
}}
fclose(f1);
fclose(tmp1);
if (i!=0){
interfaceAdmin=lookup_widget(objet_graphique,"interfaceAdmin");
treeview1=lookup_widget(interfaceAdmin,"treeview1");
afficher_reclamationrecherchee(treeview1);
remove("tmp1.txt");
}
}


void
on_button20_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
FILE *f1;
FILE *tmp1;
Reclamation r;
char ch1[20];
input1=lookup_widget(objet_graphique,"entry13");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
f1=fopen("/home/takwa/Desktop/Projet/src/fichier.txt","r");
tmp1=fopen("/home/takwa/Desktop/Projet/src/tmp1.txt","w");
while(fscanf(f1,"%s %s %s %s\n",r.nom,r.prenom,r.Datereclamation,r.reclamation)!=EOF)
{strcat(r.nom," ");
strcat(r.nom,r.prenom);
if(strcmp(ch1,r.nom)!=0)
{
fprintf(tmp1,"%s %s %s\n",r.nom,r.Datereclamation,r.reclamation);
}}
fclose(f1);
fclose(tmp1);
remove("/home/takwa/Desktop/Projet/src/fichier.txt");
rename("/home/takwa/Desktop/Projet/src/tmp1.txt","/home/takwa/Desktop/Projet/src/fichier.txt");



}


void
on_button22_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input2;
FILE *f;
FILE *tmp;
Reclamation r;
char ch[20];
input2=lookup_widget(objet_graphique,"entry14");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("/home/takwa/Desktop/Projet/src/fichier1.txt","r");
tmp=fopen("tmp.txt","w");
while(fscanf(f,"%s %s %s %s\n",r.nom,r.prenom,r.Datereclamation,r.reclamation)!=EOF)
{strcat(r.nom," ");
strcat(r.nom,r.prenom);
if(strcmp(ch,r.nom)!=0)
{
fprintf(tmp,"%s %s %s\n",r.nom,r.Datereclamation,r.reclamation);
}}
fclose(f);
fclose(tmp);
remove("/home/takwa/Desktop/Projet/src/fichier1.txt");
rename("/home/takwa/Desktop/Projet/src/tmp.txt","fichier1.txt");

}


void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input2;

GtkWidget *interfaceAgent;
GtkWidget *treeview2;
FILE *f;
FILE *tmp;
Reclamation r;
char ch[20];
int i=0;
input2=lookup_widget(objet_graphique,"entry14");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input2)));

f=fopen("fichier1.txt","r");
tmp=fopen("tmp.txt","w");
while(fscanf(f,"%s %s %s %s\n",r.nom,r.prenom,r.Datereclamation,r.reclamation)!=EOF)
{strcat(r.nom," ");
strcat(r.nom,r.prenom);
if(strcmp(ch,r.nom)==0)
{i++;
fprintf(tmp,"%s %s %s\n",r.nom,r.Datereclamation,r.reclamation);
break;
}}
fclose(f);
fclose(tmp);
if (i!=0){
interfaceAgent=lookup_widget(objet_graphique,"interfaceAgent");
treeview2=lookup_widget(interfaceAgent,"treeview2");
afficher_reclamationrecherchee(treeview2);
remove("tmp.txt");
}
}

