
#include <stdio.h>
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
#include <stdlib.h>
enum
{  
    NOM=0,
    PRENOM,
    DATE,
    RECLAMATION,
    COLUMNS
}; 
char strnospace[50],strspaces[50];

 char* strnspace(char c[])
{
int i;
char ch[50];

strcpy(ch,c);

for(i=0;ch[i]!='\0';i++)
	{
	if(ch[i]==' ')
		{
		ch[i]='_';
		}

	}
strcpy(strnospace,ch);
return strnospace;


}
 


 
char* strspace(char c[])
{
int i;


for(i=0;c[i]!='\0';i++)
	{
	if(c[i]=='_')
		{
		c[i]=' ';
		}

	}

return c;
}
  
void ajouter_reclamation(Reclamation r)
{FILE *f;
f=fopen("fichier.txt","a+");
if(f!=NULL) 

{
strcpy (r.nom,strnspace(r.nom));
strcpy (r.prenom,strnspace(r.prenom));
strcpy(r.Datereclamation,strnspace(r.Datereclamation));
strcpy(r.reclamation,strnspace(r.reclamation));
fprintf(f,"%s %s %s %s\n", r.nom, r.prenom,r.Datereclamation,r.reclamation);


}
fclose(f);

}
void ajouter1_reclamation(Reclamation r)
{FILE *f;
f=fopen("fichier1.txt","a+");
if(f!=NULL)
{ strcpy (r.nom,strnspace(r.nom));
strcpy (r.prenom,strnspace(r.prenom));
strcpy(r.Datereclamation,strnspace(r.Datereclamation));
strcpy(r.reclamation,strnspace(r.reclamation));
fprintf(f,"%s %s %s %s\n",r.nom, r.prenom,r.Datereclamation,r.reclamation);
}
fclose(f);
}
void afficher_reclamation(GtkWidget *treeview1)
{   
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   

   GtkListStore *store;
   char nom[30];
   char prenom[30];
   char Datereclamation [30];
   char reclamation[300];
   store=NULL;
   FILE *f;
   int COLUMNS=4;
   store=gtk_tree_view_get_model(treeview1);
   if (store==NULL)
   {

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Date de la reclamation",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Reclamation",renderer,"text",RECLAMATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f= fopen("fichier.txt","r");

      while(fscanf(f,"%s %s %s %s\n", nom,prenom,Datereclamation,reclamation)!=EOF)
   {

strspace(nom);
strspace(prenom);
strspace(Datereclamation);


strspace(reclamation);





  gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,DATE,Datereclamation,RECLAMATION,reclamation, -1);
}
fclose(f);

gtk_tree_view_set_model (GTK_TREE_VIEW(treeview1), GTK_TREE_MODEL (store));
g_object_unref (store);
}
void afficher1_reclamation(GtkWidget *treeview2)
{   
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   

   GtkListStore *store;
   char nom[30];
   char prenom[30];
   char Datereclamation [30];
   char reclamation[300];
   store=NULL;
   FILE *f;
   int COLUMNS=4;
   store=gtk_tree_view_get_model(treeview2);
   if (store==NULL)
   {

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Date de la reclamation",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Reclamation",renderer,"text",RECLAMATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview2), column);}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f= fopen("fichier1.txt","r");

      while(fscanf(f,"%s %s %s %s\n", nom,prenom,Datereclamation,reclamation)!=EOF)
   {
strspace(nom);
strspace(prenom);
strspace(Datereclamation);
strspace(reclamation);

  gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,DATE,Datereclamation,RECLAMATION,reclamation, -1);
}
fclose(f);

gtk_tree_view_set_model (GTK_TREE_VIEW(treeview2), GTK_TREE_MODEL (store));
g_object_unref (store);
}

void afficher_reclamationrecherchee(GtkWidget *treeview1)
{   
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;
   GtkTreeIter iter;
   

   GtkListStore *store;
   char nom[30];
   char prenom[30];
   char Datereclamation [30];
   char reclamation[300];
   store=NULL;
   FILE *f;
   int COLUMNS=4;
   store=gtk_tree_view_get_model(treeview1);
   if (store==NULL)
   {

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Date de la reclamation",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);

    renderer = gtk_cell_renderer_text_new ();
   column=gtk_tree_view_column_new_with_attributes("Reclamation",renderer,"text",RECLAMATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), column);}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f= fopen("tmp.txt","r");


      while(fscanf(f,"%s %s %s %s\n", nom,prenom,Datereclamation,reclamation)!=EOF)
   {

  gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,DATE,Datereclamation,RECLAMATION,reclamation, -1);
}
fclose(f);

gtk_tree_view_set_model (GTK_TREE_VIEW(treeview1), GTK_TREE_MODEL (store));
g_object_unref (store);
}

