#include <gtk/gtk.h>


void
on_annuler1_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

/*void
on_envoyer1_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);*/

void
on_button8_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

/*void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);*/

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_envoyer1_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
