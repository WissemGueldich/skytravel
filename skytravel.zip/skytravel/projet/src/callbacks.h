#include <gtk/gtk.h>


void
on_ajouter1_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_modifier1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

                                      
void
on_retour_aj_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retour_sup_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);


void
on_modifier2_clicked                   (GtkWidget        *button,
                                        gpointer         user_data);

void
on_ajouter2_clicked                    (GtkWidget        *button,
                                        gpointer         user_data);

void
on_retour_mod_clicked                  (GtkWidget        *button,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_aff_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_supprimer2_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);



void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
