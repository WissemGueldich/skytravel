#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fct.h"

void
on_update_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *gestion_agents;
  GtkWidget *liste;
  gestion_agents=lookup_widget(objet,"gestion_agents");
  liste=lookup_widget(gestion_agents,"liste");
  afficher_agent(liste);


}

void on_ajouter_clicked(GtkWidget *objet, gpointer user_data)
{   GtkWidget *gestion_agents;
  GtkWidget *ajout_agent;


  gestion_agents=lookup_widget(objet,"gestion_agents");
  
  
  ajout_agent=lookup_widget(objet,"ajout_agent");
  ajout_agent=create_ajout_agent();

  gtk_widget_show(ajout_agent);


}



void on_ajouter2_clicked(GtkWidget *objet, gpointer user_data)
{ FILE *f;
  agent g ;
  char id[20];
  char nom[20];
  char prenom[20];
  char passwd[20];
  char date_rec[20];
  char num_tel[20] ;
  

  GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
  
  GtkWidget *output_id_already_exist;
  GtkWidget *output1, *output2, *output3, *output4, *output6;
  GtkWidget *gestion_agents;
  GtkWidget *ajout_agent;
  GtkWidget *output;
 
  ajout_agent=lookup_widget(objet,"ajout_agent");
  input1=lookup_widget(objet,"entrynom");
  input2=lookup_widget(objet,"entryprenom");
  input3=lookup_widget(objet,"entryid");
  input4=lookup_widget(objet,"entrypasswd");
  input5=lookup_widget(objet,"entrydaterec");
  input6=lookup_widget(objet,"entrynumtel");
 
  
  
   output_id_already_exist= lookup_widget(objet, "id_already_exist");
   output1=lookup_widget(objet,"label1");
   output2=lookup_widget(objet,"label2");
   output3=lookup_widget(objet,"label3");
   output4=lookup_widget(objet,"label4");
   output6=lookup_widget(objet,"label6");


     strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
     strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
     strcpy(id, gtk_entry_get_text(GTK_ENTRY(input3)));
     strcpy(passwd,gtk_entry_get_text(GTK_ENTRY(input4)));
     strcpy(date_rec,gtk_entry_get_text(GTK_ENTRY(input5)));
     strcpy(num_tel,gtk_entry_get_text(GTK_ENTRY(input6)));

     
  
   g=chercher(id);
  if (strcmp(g.id , "-1")!=0)
  {
    gtk_label_set_text(GTK_LABEL(output_id_already_exist), "     Cet id existe déjà!\nVeuillez insérer un id différent");
  }
  else

   { 
     
      if ((controle_saisie_char(nom)==0)  || (strcmp(nom,"")==0))

     {  
        gtk_label_set_text(GTK_LABEL(output1),"*Donnée invalide");
     }
     else
        {if ((controle_saisie_char(prenom)==0)  || (strcmp(prenom,"")==0))
          {
             gtk_label_set_text(GTK_LABEL(output2),"*Donnée invalide");
        
          }
         else
           {if ((controle_saisie_id(id)==0)  || (strcmp(id,"")==0))
              {
              gtk_label_set_text(GTK_LABEL(output3),"*Donnée invalide");
        
              }
            else 
                {if  (strcmp(passwd,"")==0)
                  {
                     gtk_label_set_text(GTK_LABEL(output4),"*Donnée invalide");
        
                  }
                 else
                  {  if ((controle_saisie_num(num_tel)==0) || (strcmp(num_tel,"")==0))
                              {   
                                gtk_label_set_text(GTK_LABEL(output6),"*Donnée invalide");

                              }
                     else
                              {
                                strcpy(g.nom,nom);
                                strcpy(g.prenom,prenom);
                                strcpy(g.passwd,passwd);
                                strcpy(g.id,id);
                                strcpy(g.date_rec,date_rec);
                                strcpy(g.num_tel,num_tel);
                          


                                ajouter(g); 
                                gestion_agents=lookup_widget(objet,"gestion_agents");
                                gtk_widget_hide(ajout_agent);
    
                                gestion_agents=create_gestion_agents();

                                gtk_widget_show(gestion_agents); 
                              
      
                               }
                        
                  }
                } 
            } 
        }
    }

}







void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *ajout_agent;
  GtkWidget *gestion_agents;
   
  
  ajout_agent=lookup_widget(objet,"ajout_agent");
  gestion_agents=lookup_widget(objet,"gestion_agents");
  
  gtk_widget_hide(ajout_agent);
 
   
}












 






void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *gestion_agents;
  GtkWidget *recherche;
  
  gestion_agents=lookup_widget(objet,"gestion_agents");
  recherche=lookup_widget(objet,"recherche");

  
 
   recherche=create_recherche();

   gtk_widget_show(recherche); 



}


void
on_confirmer_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{  GtkWidget *input ;
  GtkWidget *output_not_found; 
  GtkWidget *gestion_agents;
  GtkWidget *recherche;
  GtkWidget *modif_agent;
  GtkWidget *output1, *output2, *output3, *output4, *output5, *output6;
  agent g;
  char id[20];
  
    recherche=lookup_widget(objet,"recherche");
  input = lookup_widget(objet, "entryid");
  output_not_found= lookup_widget(objet, "not_found");

   strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
   g=chercher(id);
  if (strcmp(g.id , "-1")==0)
  {
    gtk_label_set_text(GTK_LABEL(output_not_found), "Cet utilisateur n'existe pas!");
  }
  else
  {
    
   
     modif_agent=lookup_widget(objet,"modif_agent");
     gtk_widget_hide(recherche);
 
     modif_agent=create_modif_agent();

     gtk_widget_show(modif_agent); 

   output1=lookup_widget(modif_agent,"entrynom");
  output2=lookup_widget(modif_agent,"entryprenom");
  output3=lookup_widget(modif_agent,"entryid");
  output4=lookup_widget(modif_agent,"entrypasswd");
  output5=lookup_widget(modif_agent,"entrydaterec");
  output6=lookup_widget(modif_agent,"entrynumtel");
  gtk_entry_set_text(GTK_ENTRY(output1),g.nom);
  gtk_entry_set_text(GTK_ENTRY(output2),g.prenom);
  gtk_entry_set_text(GTK_ENTRY(output3),g.id);
  gtk_entry_set_text(GTK_ENTRY(output4),g.passwd);
  gtk_entry_set_text(GTK_ENTRY(output5),g.date_rec);
  gtk_entry_set_text(GTK_ENTRY(output6),g.num_tel);
  
  
  }
  
 
  
  

} 

void
on_confirmer2_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{ agent g;
  GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
  GtkWidget *gestion_agents;
  GtkWidget *modif_agent;
  

 
  gestion_agents=lookup_widget(objet,"gestion_agents"); 
  modif_agent=lookup_widget(objet,"modif_agent");

  input1=lookup_widget(objet,"entrynom");
  input2=lookup_widget(objet,"entryprenom");
  input3=lookup_widget(objet,"entryid");
  input4=lookup_widget(objet,"entrypasswd");
  input5=lookup_widget(objet,"entrydaterec");
  input6=lookup_widget(objet,"entrynumtel");

  strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(g.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(g.passwd,gtk_entry_get_text(GTK_ENTRY(input4)));
  strcpy(g.date_rec,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(g.num_tel,gtk_entry_get_text(GTK_ENTRY(input6)));
  
  modifier(g);

   
  
  gtk_widget_hide(modif_agent);



}



 

void
on_annuler2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{   GtkWidget *gestion_agents;
    GtkWidget *modif_agent;

    modif_agent=lookup_widget(objet,"modif_agent");
    gestion_agents=lookup_widget(objet,"gestion_agents");
    
    gtk_widget_hide(modif_agent);
    


}





void 
on_supprimer_clicked                   (GtkWidget      *objet,
                                          gpointer         user_data)
{ GtkWidget *gestion_agents;
  GtkWidget *recherche2;
  
  
  gestion_agents=lookup_widget(objet,"gestion_agents");
  recherche2=lookup_widget(objet,"recherche2");

  
 
   recherche2=create_recherche2();

   gtk_widget_show(recherche2); 



}


void on_confirm_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{  
     GtkWidget *input ;
  GtkWidget *output_not_found; 
  GtkWidget *gestion_agents;
  GtkWidget *recherche2;
  GtkWidget *output;

  GtkWidget *output1, *output2, *output3, *output4, *output5, *output6;
  agent g;
  char id[20];
  
  recherche2=lookup_widget(objet,"recherche2");
  input = lookup_widget(objet, "entryid");
  output_not_found= lookup_widget(objet, "not_found");

   strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
   g=chercher(id);
  if (strcmp(g.id , "-1")==0)
  {
    gtk_label_set_text(GTK_LABEL(output_not_found), "Cet utilisateur n'existe pas!");
  }
  else
  {
    supprimer(g);
    gestion_agents=lookup_widget(objet,"gestion_agents");
      gestion_agents=create_gestion_agents();
        gtk_widget_destroy(recherche2);
       
       output=lookup_widget(gestion_agents,"labelsucces");
       gtk_label_set_text(GTK_LABEL(output),"Agent supprimé avec succès");
      
    
     
     
   }
}


