#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <gtk/gtk.h>




struct client
{ char nom[20];
  char prenom[20];
  char id[20];
  char passwd[20];
  char date_adh[20] ;
  char num_tel[20] ;

};
typedef struct client  client ;

int controle_saisie_char(char x[20]);
int controle_saisie_num(char x[20]);
int controle_saisie_id(char x[20]);


client chercher(char x[]);
void ajouter(client c);
void afficher_client(GtkWidget *liste); 
void modifier (client c);
void supprimer (client c);

