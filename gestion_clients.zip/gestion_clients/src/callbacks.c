#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fct.h"


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *gestion_clients;
  GtkWidget *recherche;
  
  gestion_clients=lookup_widget(objet,"gestion_clients");
  recherche=lookup_widget(objet,"recherche");

  
 
   recherche=create_recherche();

   gtk_widget_show(recherche); 

}


void
on_ajouter_clicked                     (GtkWidget     *objet,
                                        gpointer         user_data)
{    GtkWidget *gestion_clients;
  GtkWidget *ajout_client;


  gestion_clients=lookup_widget(objet,"gestion_clients");
  
  
  ajout_client=lookup_widget(objet,"ajout_client");
  ajout_client=create_ajout_client();

  gtk_widget_show(ajout_client);

}


void
on_supprimer_clicked                   (GtkWidget    *objet,
                                        gpointer         user_data)
{   GtkWidget *gestion_clients;
  GtkWidget *recherche2;
  
  
  gestion_clients=lookup_widget(objet,"gestion_clients");
  recherche2=lookup_widget(objet,"recherche2");

  
 
   recherche2=create_recherche2();

   gtk_widget_show(recherche2); 

}


void
on_update_clicked                      (GtkWidget    *objet,
                                        gpointer         user_data)
{     GtkWidget *gestion_clients;
  GtkWidget *liste;
  gestion_clients=lookup_widget(objet,"gestion_clients");
  liste=lookup_widget(gestion_clients,"liste");
  afficher_client(liste);

}


void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{  GtkWidget *ajout_client;
  GtkWidget *gestion_clients;
   
  
  ajout_client=lookup_widget(objet,"ajout_client");
  gestion_clients=lookup_widget(objet,"gestion_clients");
  
  gtk_widget_hide(ajout_client);
 
   

}


void
on_ajouter2_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{  FILE *f;
  client c;
  char id[20];
  char nom[20];
  char prenom[20];
  char passwd[20];
  char date_adh[20];
  char num_tel[20] ;
  

  GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
  
  GtkWidget *output_id_already_exist;
  GtkWidget *output1, *output2, *output3, *output4, *output6;
  GtkWidget *gestion_clients;
  GtkWidget *ajout_client;
  GtkWidget *output;
 
  ajout_client=lookup_widget(objet,"ajout_client");
  input1=lookup_widget(objet,"entrynom");
  input2=lookup_widget(objet,"entryprenom");
  input3=lookup_widget(objet,"entryid");
  input4=lookup_widget(objet,"entrypasswd");
  input5=lookup_widget(objet,"entrydateadh");
  input6=lookup_widget(objet,"entrynumtel");
 
  
  
   output_id_already_exist= lookup_widget(objet, "id_already_exist");
   output1=lookup_widget(objet,"label1");
   output2=lookup_widget(objet,"label2");
   output3=lookup_widget(objet,"label3");
   output4=lookup_widget(objet,"label4");
   output6=lookup_widget(objet,"label6");


     strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
     strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
     strcpy(id, gtk_entry_get_text(GTK_ENTRY(input3)));
     strcpy(passwd,gtk_entry_get_text(GTK_ENTRY(input4)));
     strcpy(date_adh,gtk_entry_get_text(GTK_ENTRY(input5)));
     strcpy(num_tel,gtk_entry_get_text(GTK_ENTRY(input6)));

     
  
   c=chercher(id);
  if (strcmp(c.id , "-1")!=0)
  {
    gtk_label_set_text(GTK_LABEL(output_id_already_exist), "     Cet id existe déjà!  Veuillez insérer un id différent");
  }
  else

   { 
     
      if ((controle_saisie_char(nom)==0)  || (strcmp(nom,"")==0))

     {  
        gtk_label_set_text(GTK_LABEL(output1),"*Donnée invalide");
     }
     else
        {if ((controle_saisie_char(prenom)==0)  || (strcmp(prenom,"")==0))
          {
             gtk_label_set_text(GTK_LABEL(output2),"*Donnée invalide");
        
          }
         else
           {if ((controle_saisie_id(id)==0)  || (strcmp(id,"")==0))
              {
              gtk_label_set_text(GTK_LABEL(output3),"*Donnée invalide");
        
              }
            else 
                {if  (strcmp(passwd,"")==0)
                  {
                     gtk_label_set_text(GTK_LABEL(output4),"*Donnée invalide");
        
                  }
                 else
                  {  if ((controle_saisie_num(num_tel)==0) || (strcmp(num_tel,"")==0))
                              {   
                                gtk_label_set_text(GTK_LABEL(output6),"*Donnée invalide");

                              }
                     else
                              {
                                strcpy(c.nom,nom);
                                strcpy(c.prenom,prenom);
                                strcpy(c.passwd,passwd);
                                strcpy(c.id,id);
                                strcpy(c.date_adh,date_adh);
                                strcpy(c.num_tel,num_tel);
                          


                                ajouter(c); 
                                gestion_clients=lookup_widget(objet,"gestion_clients");
                                gtk_widget_hide(ajout_client);
    
                                
                              
      
                               }
                        
                  }
                } 
            } 
        }
    }


}


void
on_confirmer2_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
      client c ;
  GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
  GtkWidget *gestion_clients;
  GtkWidget *modif_client;
  

 
  gestion_clients=lookup_widget(objet,"gestion_clients"); 
  modif_client=lookup_widget(objet,"modif_client");

  input1=lookup_widget(objet,"entrynom");
  input2=lookup_widget(objet,"entryprenom");
  input3=lookup_widget(objet,"entryid");
  input4=lookup_widget(objet,"entrypasswd");
  input5=lookup_widget(objet,"entrydateadh");
  input6=lookup_widget(objet,"entrynumtel");

  strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(c.passwd,gtk_entry_get_text(GTK_ENTRY(input4)));
  strcpy(c.date_adh,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(c.num_tel,gtk_entry_get_text(GTK_ENTRY(input6)));
  
  modifier(c);

   
  
  gtk_widget_hide(modif_client);

}


void
on_annuler2_clicked                    (GtkWidget     *objet,
                                        gpointer         user_data)
{
    GtkWidget *gestion_clients;
    GtkWidget *modif_client;

    modif_client=lookup_widget(objet,"modif_client");
    gestion_clients=lookup_widget(objet,"gestion_clients");
    
    gtk_widget_hide(modif_client);
    

}


void
on_confirmer_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{
    GtkWidget *input ;
  GtkWidget *output_not_found; 
  GtkWidget *gestion_clients;
  GtkWidget *recherche;
  GtkWidget *modif_client;
  GtkWidget *output1, *output2, *output3, *output4, *output5, *output6;
  client c ;
  char id[20];
  
    recherche=lookup_widget(objet,"recherche");
  input = lookup_widget(objet, "entryid");
  output_not_found= lookup_widget(objet, "not_found");

   strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
   c=chercher(id);
  if (strcmp(c.id , "-1")==0)
  {
    gtk_label_set_text(GTK_LABEL(output_not_found), "Cet utilisateur n'existe pas!");
  }
  else
  {
    
   
     modif_client=lookup_widget(objet,"modif_client");
     gtk_widget_hide(recherche);
 
     modif_client=create_modif_client();

     gtk_widget_show(modif_client); 

   output1=lookup_widget(modif_client,"entrynom");
  output2=lookup_widget(modif_client,"entryprenom");
  output3=lookup_widget(modif_client,"entryid");
  output4=lookup_widget(modif_client,"entrypasswd");
  output5=lookup_widget(modif_client,"entrydateadh");
  output6=lookup_widget(modif_client,"entrynumtel");
  gtk_entry_set_text(GTK_ENTRY(output1),c.nom);
  gtk_entry_set_text(GTK_ENTRY(output2),c.prenom);
  gtk_entry_set_text(GTK_ENTRY(output3),c.id);
  gtk_entry_set_text(GTK_ENTRY(output4),c.passwd);
  gtk_entry_set_text(GTK_ENTRY(output5),c.date_adh);
  gtk_entry_set_text(GTK_ENTRY(output6),c.num_tel);
  
  
  }
  
 
  
  
}


void
on_confirm_clicked                     (GtkWidget     *objet,
                                        gpointer         user_data)
{   GtkWidget *input ;
  GtkWidget *output_not_found; 
  GtkWidget *gestion_clients;
  GtkWidget *recherche2;
  GtkWidget *output;

  GtkWidget *output1, *output2, *output3, *output4, *output5, *output6;
  client c ;
  char id[20];
  
  recherche2=lookup_widget(objet,"recherche2");
  input = lookup_widget(objet, "entryid");
  output_not_found= lookup_widget(objet, "not_found");

   strcpy(id, gtk_entry_get_text(GTK_ENTRY(input)));
   c=chercher(id);
  if (strcmp(c.id , "-1")==0)
  {
    gtk_label_set_text(GTK_LABEL(output_not_found), "Cet utilisateur n'existe pas!");
  }
  else
  {
    supprimer(c);
    gestion_clients=lookup_widget(objet,"gestion_clients");
      gestion_clients=create_gestion_clients();
        gtk_widget_destroy(recherche2);
       
       output=lookup_widget(gestion_clients,"labelsucces");
       gtk_label_set_text(GTK_LABEL(output),"Agent supprimé avec succès");
      
    
     
     
   }

}




