#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"voiture.h"

enum
{ MODELE,
COULEUR,
MATRICULE,
PRIX,
COLUMNS
};
///////////////////////////////////////////////////////////////

void ajoutervoiture(voiture v)
{
FILE *f,*g;
f=fopen("voiture.txt","a+");
g=fopen("voituredispo.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s\n",v.matricule,v.modele,v.couleur,v.prix);

fclose(f);
fprintf(g,"%s %s %s %s\n", v.matricule , v.modele, v.couleur, v.prix);
fclose(g);
}
}

//////////////////////////////////////////////////////////

void affichervoiture(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char matricule[20];
char modele[20];
char couleur[20];
char prix[20];
store=NULL ;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();						   column=gtk_tree_view_column_new_with_attributes("matricule",renderer,"text",MATRICULE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();						   column=gtk_tree_view_column_new_with_attributes("modele",renderer,"text",MODELE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();					   column=gtk_tree_view_column_new_with_attributes("couleur",renderer,"text",COULEUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();					   column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("voiture.txt","r");
if(f==NULL)
{
return;
}
else
{ f=fopen("voiture.txt","a+");
   while(fscanf(f,"%s %s %s %s\n",matricule,modele,couleur,prix)!=EOF)
    {
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,MATRICULE,matricule,MODELE,modele,COULEUR,couleur,PRIX,prix,-1);

     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}
}
////////////////////////////////////////////////////////////
void supprimervoiture( char matricule[])
{
voiture v;
FILE *f;
FILE *tmp=NULL;
f=fopen("voiture.txt","r");

if((f!=NULL) )
{
while(fscanf(f,"%s %s %s %s\n", v.matricule,v.modele,v.couleur,v.prix)!=EOF)
{
if(strcmp(matricule,v.matricule)!=0)
{
tmp=fopen("tmp.txt","a+");
fprintf(tmp,"%s %s %s %s\n", v.matricule,v.modele,v.couleur,v.prix);
fclose(tmp);
}
}
}
fclose(f);
remove("voiture.txt");
rename("tmp.txt","voiture.txt");
}
/////////////////////////////////////////////////////
void modifiervoiture(voiture v)
{
char prix[20],couleur[20],modele[20],matricule[20];
FILE *f;
FILE *tmp;
f=fopen("voiture.txt","r");
tmp=fopen("tmp.txt","a");

while(fscanf(f,"%s %s %s %s\n", matricule,modele,couleur,prix)!=EOF)
{
if(strcmp(matricule,v.matricule)!=0)
{
fprintf(tmp,"%s %s %s %s\n", matricule,v.modele,v.couleur,v.prix);
}
else 
{
fprintf(tmp,"%s %s %s %s\n",matricule,modele,couleur,prix);
}
}
fclose(f);
fclose(tmp);
remove("voiture.txt");
rename("tmp.txt","voiture.txt");


}



void cherchervoiture(char matricule[],int *a)
{
voiture v;
FILE *f;
f=fopen("voiture.txt","r");
while ((fscanf(f,"%s %s %s %s\n", v.matricule,v.modele,v.couleur,v.prix)!=EOF))
{if(strcmp(matricule,v.matricule)==0)
{*a=1;}
}
}

///////////////////////////////////////////////////////

void reserver(reservation r , int ve)
{
char matricule[100];
char couleur[100];
char modele[100];
char prix[100];
voiture v;

FILE *f,*g;
g=fopen("voituredispo.txt","r");
f=fopen("voiturereserve.txt","a+");



while(fscanf(g,"%s %s %s %s\n",v.matricule,v.modele,v.couleur,v.prix)!=EOF)
{
if((strcmp(v.modele,r.v.modele)==0 )&&(strcmp(v.couleur,r.v.couleur)==0)&&(ve==1))
{
fprintf(f,"%s %s %s %s %d %d %d %d %d %d\n",v.matricule,
r.v.modele,r.v.couleur,v.prix ,r.de.jour,r.de.mois,r.de.annee
,r.ju.jour,r.ju.mois,r.ju.annee);
supprimer(v);
fclose(g);
fclose(f);
break;
}
}
}

//////////////////////////////////////////////////////////////////
int verifier(char couleur[20],char modele[20])
{

voiture v;
int ve=0;
FILE *f;
f=fopen("voituredispo.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s\n",v.matricule, v.modele,v.couleur,v.prix)!=EOF)
	{
	if((strcmp(modele,v.modele)==0)&& (strcmp(couleur,v.couleur)==0))
	{
	
	
	ve=1;
	
	}
}	}
fclose(f);
return ve;
}


///////////////////////////
void supprimer(voiture v)
{voiture vo;

FILE *f,*g=NULL;
f=fopen("voituredispo.txt","r");

if(f!=NULL)
{g=fopen("tmp2.txt","a+");
while(fscanf(f,"%s %s %s %s\n",vo.matricule, vo.modele,vo.couleur,vo.prix)!=EOF)
{
if (strcmp(v.matricule,vo.matricule)!=0)
{
fprintf(g,"%s %s %s %s\n", vo.matricule,vo.modele,vo.couleur,vo.prix);

}
fclose(g);
}
}
fclose(f);

remove("voituredispo.txt");
rename("tmp2.txt","voituredispo.txt");
}
////////////////////////
void afficher(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char matricule[20];
char modele[20];
char couleur[20];
char prix[20];
store=NULL ;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();						   column=gtk_tree_view_column_new_with_attributes("matricule",renderer,"text",MATRICULE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();						   column=gtk_tree_view_column_new_with_attributes("modele",renderer,"text",MODELE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();					   column=gtk_tree_view_column_new_with_attributes("couleur",renderer,"text",COULEUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new();					   column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("voituredispo.txt","r");
if(f==NULL)
{
return;
}
else
{ f=fopen("voituredispo.txt","a+");
   while(fscanf(f,"%s %s %s %s\n",matricule,modele,couleur,prix)!=EOF)
    {
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,MATRICULE,matricule,MODELE,modele,COULEUR,couleur,PRIX,prix,-1);

     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}
}












