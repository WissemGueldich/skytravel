#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <gtk/gtk.h>




struct agent
{ char nom[20];
  char prenom[20];
  char id[20];
  char passwd[20];
  char date_rec[20] ;
  char num_tel[20] ;

};
typedef struct agent  agent ;

int controle_saisie_char(char x[20]);
int controle_saisie_num(char x[20]);
int controle_saisie_id(char x[20]);


agent chercher(char x[]);
void ajouter(agent ag);
void afficher_agent(GtkWidget *liste); 
void modifier (agent g);
void supprimer (agent g);

