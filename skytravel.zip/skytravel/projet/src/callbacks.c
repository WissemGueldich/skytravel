#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "voiture.h"


reservation r;


void on_ajouter1_clicked (GtkWidget *button, gpointer user_data)
{
GtkWidget *wajouter,*agent;
agent=lookup_widget(button,"agent");
gtk_widget_destroy(agent);
wajouter=create_wajouter();
gtk_widget_show(wajouter);
}
////////////////////////////////////



void
on_modifier1_clicked                   (GtkWidget     *button,
                                        gpointer         user_data)
{
GtkWidget *wmodifier,*agent;
agent=lookup_widget(button,"agent");
gtk_widget_destroy(agent);
wmodifier=create_wmodifier();
gtk_widget_show(wmodifier);

}
/////////////////////////////////



void
on_supprimer1_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *wsupprimer,*agent,*treeview1;
agent=lookup_widget(button,"agent");
gtk_widget_destroy(agent);


wsupprimer=create_wsupprimer();
gtk_widget_show(wsupprimer);

treeview1=lookup_widget(wsupprimer,"treeview1");
affichervoiture(treeview1);
}

//////////////////////////////////




void
on_retour_aj_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *wajouter,*agent;
wajouter=lookup_widget(button,"wajouter");
gtk_widget_destroy(wajouter);
agent=create_agent();
gtk_widget_show(agent);
}

/////////////////////////////////

void
on_retour_sup_clicked                  (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *wsupprimer,*agent;
wsupprimer=lookup_widget(button,"wsupprimer");
gtk_widget_destroy(wsupprimer);
agent=create_agent();
gtk_widget_show(agent);

}
////////////////////////////////


void
on_modifier2_clicked                   (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *wmodifier,*output1,*treeview2,*wafficher;
voiture v;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;

input1=lookup_widget(button,"entry7");
input2=lookup_widget(button,"entry8");
input3=lookup_widget(button,"entry9");

strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.modele,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.couleur,gtk_entry_get_text(GTK_ENTRY(input3)));

output1=lookup_widget(button,"entry6");
strcpy(v.matricule,gtk_entry_get_text(GTK_ENTRY(output1)));
modifiervoiture(v);


wmodifier=lookup_widget(button,"wmodifier");
gtk_widget_destroy(wmodifier);
wafficher=lookup_widget(button,"wafficher");
wafficher=create_wafficher();
gtk_widget_show(wafficher);



treeview2=lookup_widget(wafficher,"treeview2");
affichervoiture(treeview2);
}

///////////////////////////


void
on_ajouter2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
voiture v;
GtkWidget *input1,*input2,*input3,*input4,*treeview2;
GtkWidget *wajouter,*wafficher;
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
input3=lookup_widget(button,"entry3");
input4=lookup_widget(button,"entry4");

strcpy(v.matricule,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(v.modele,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v.couleur,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(input4)));
ajoutervoiture(v);
wajouter=lookup_widget(button,"wajouter");
gtk_widget_destroy(wajouter);
wafficher=lookup_widget(button,"wafficher");
wafficher=create_wafficher();
gtk_widget_show(wafficher);
treeview2=lookup_widget(wafficher,"treeview2");
affichervoiture(treeview2);
}
////////////////////////////////



void
on_retour_mod_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *wmodifier,*agent;

wmodifier=lookup_widget(button,"wmodifier");
gtk_widget_destroy(wmodifier);

agent=create_agent();
gtk_widget_show(agent);

}

////////////////////////////////////////




void
on_recherche_clicked (GtkWidget *button,gpointer  user_data)
{
voiture v;
int a;
char matricule[20];
GtkWidget *output1,*output2,*output3,*output4;
GtkWidget *wmodifier;
output1=lookup_widget(button,"entry6");
strcpy(matricule,gtk_entry_get_text(GTK_ENTRY(output1)));


output1=lookup_widget(button,"label20");
output2=lookup_widget(button,"label21");
output3=lookup_widget(button,"label22");
output4=lookup_widget(button,"label23");
cherchervoiture(matricule,&a);
FILE *f;
f=fopen("voiture.txt","r");
while(fscanf(f,"%s %s %s %s\n",v.matricule,v.modele,v.couleur,v.prix)!=EOF)
{
if(a==1)
{
gtk_label_set_text(GTK_LABEL(output1),"");
gtk_label_set_text(GTK_LABEL(output2),v.prix);
gtk_label_set_text(GTK_LABEL(output3),v.modele);
gtk_label_set_text(GTK_LABEL(output4),v.couleur);
}

else
{
gtk_label_set_text(GTK_LABEL(output1),"matricule introuvable");
}
}
}
/////////////////////////////////////////////






void
on_retour_aff_clicked (GtkWidget *button , gpointer user_data)
{
GtkWidget *wajouter,*wafficher;

wafficher=lookup_widget(button,"wafficher");
gtk_widget_destroy(wafficher);

wajouter=create_wajouter();
gtk_widget_show(wajouter);
}


void
on_supprimer2_clicked (GtkWidget *button ,
gpointer  user_data)
{
char matricule[20];
GtkWidget *wsupprimer;
GtkWidget *input1,*treeview1;

input1=lookup_widget(button,"entry5");
strcpy(matricule,gtk_entry_get_text(GTK_ENTRY(input1)));

supprimervoiture(matricule);
wsupprimer=lookup_widget(button,"wsupprimer");
gtk_widget_destroy(wsupprimer);
wsupprimer=create_wsupprimer();
gtk_widget_show(wsupprimer);

treeview1=lookup_widget(wsupprimer,"treeview1");
affichervoiture(treeview1);
}

/////////////////////////////////


void
on_valider_clicked                     (GtkWidget     *button,
                                        gpointer         user_data)
{
GtkWidget *jour1, *jour2, *mois1, *mois2, *annee1, *annee2, *treeview3;
GtkWidget *combobox1,*combobox2,*sortie,*wreserver,*welse;
char couleur[20],modele[20];

voiture v;
jour1=lookup_widget(button,"spinbutton1");
jour2=lookup_widget(button,"spinbutton2");
mois1=lookup_widget(button,"spinbutton3");
mois2=lookup_widget(button,"spinbutton4");
annee1=lookup_widget(button,"spinbutton5");
annee2=lookup_widget(button,"spinbutton6");
combobox1=lookup_widget(button,"combobox1");
combobox2=lookup_widget(button,"combobox2");
sortie=lookup_widget(button,"label33");
r.de.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
r.ju.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour2));
r.de.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
r.ju.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois2));
r.de.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
r.ju.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee2));

strcpy(couleur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(modele,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

strcpy(v.modele,modele);
strcpy(v.couleur,couleur);

int ve = verifier(couleur,modele);
strcpy(r.v.modele,v.modele);
strcpy(r.v.couleur,v.couleur);

if(ve==1)
{


gtk_label_set_text(GTK_LABEL(sortie),"Reservation reussite");
reserver(r,ve);

}
else 
if(ve==0)
{
wreserver=lookup_widget(button,"wreserver");
gtk_widget_destroy(wreserver);

welse=create_welse();
gtk_widget_show(welse);


treeview3=lookup_widget(welse,"treeview3");
afficher(treeview3);


}

}



//////////////////////////////////


	
void
on_confirmer_clicked    (GtkWidget     *button,
                                        gpointer         user_data)
{voiture v;
GtkWidget *welse,*treeview3;
GtkWidget *jour1, *jour2, *mois1, *mois2, *annee1, *annee2;
jour1=lookup_widget(button,"spinbutton7");
jour2=lookup_widget(button,"spinbutton10");
mois1=lookup_widget(button,"spinbutton8");
mois2=lookup_widget(button,"spinbutton11");
annee1=lookup_widget(button,"spinbutton9");
annee2=lookup_widget(button,"spinbutton12");

r.de.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
r.ju.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour2));
r.de.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
r.ju.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois2));
r.de.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
r.ju.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee2));

strcpy(v.matricule,r.v.matricule);
strcpy(v.couleur,r.v.couleur);
strcpy(v.modele,r.v.modele);
strcpy(v.prix,r.v.prix);

supprimer(v);
FILE *f;

f=fopen("voiturereserve.txt","a+");



if(f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d %d %d %d\n",r.v.matricule,
r.v.modele,r.v.couleur,r.v.prix ,r.de.jour,r.de.mois,r.de.annee
,r.ju.jour,r.ju.mois,r.ju.annee);
}
fclose(f);

welse=lookup_widget(button,"welse");
gtk_widget_destroy(welse);
welse=create_welse();
gtk_widget_show(welse);

treeview3=lookup_widget(welse,"treeview3");
afficher(treeview3);


}


//////////////////////////

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *wreserver,*welse;
welse=lookup_widget(button,"welse");
gtk_widget_destroy(welse);
wreserver=create_wreserver();
gtk_widget_show(wreserver);
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data0;
gchar *str_data1;
gchar *str_data2;
gchar *str_data3;

GtkListStore *list_store;
list_store=GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));
GtkTreeIter iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter , path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data0, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data2, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data3, -1);
}
strcpy(r.v.matricule,str_data0);
strcpy(r.v.modele,str_data1);
strcpy(r.v.couleur,str_data2);
strcpy(r.v.prix,str_data3);
}

